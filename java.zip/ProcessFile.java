package com.scalait.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import com.ibm.websphere.sca.ServiceManager;
import com.scalait.to.Planilha;
import com.scalait.to.PlanilhaTeste;

public class ProcessFile {
	/**
	 * Default constructor.
	 */
	public ProcessFile() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this implementation
	 * class.  This method should be used when passing this service to a partner reference
	 * or if you want to invoke this component service asynchronously.    
	 *
	 * @generated (com.ibm.wbit.java)
	 */
	@SuppressWarnings("unused")
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	/**
	 * Method generated to support implementation of operation "process" defined for WSDL port type 
	 * named "FileProcesser".
	 * 
	 * Please refer to the WSDL Definition for more information 
	 * on the type of input, output and fault(s).
	 */
	public String process(String file) {
//		System.out.println("##################################");
//		System.out.println("PROCESS");
//		System.out.println("##################################");
//		System.out.println("FILE: " + file);
//		System.out.println("##################################");
//		String[] fileSliced = file.split("\n");
//		String fileName = fileSliced[1].split(";")[2].substring(11);
//		fileName = fileName.substring(0, fileName.length()-1);
//		String byteArray = fileSliced[4];		
//		System.out.println("fileName: " + fileName);
//		System.out.println("##################################");
//		System.out.println("byteArray: " + byteArray);
//		System.out.println("##################################");
				
		try {
			
			/*
			 * 1 - Parsear Planilha Recebida, onde cada linha de retorno � o objeto JSON que deve ser enviado como par�metro ao Processo.
			 * Criar uma classe para cada estilo de planilha e implementar a Interface Planilha. Inst�nciar Objeto com a nova classe criada.
			 */
			Planilha sheet = new PlanilhaTeste();
			//File myFile = new File("C:\\TEMP\\Teste.xls");
			File myFile = new File("/tmp/Teste.xls");
			List<JSONObject> jsonRows = sheet.readXLSExcel(new FileInputStream(myFile));
			
			
			//REMOVER
			JSONObject teste = new JSONObject();
			teste.put("paramErrado", "ERRADO");
			jsonRows.add(teste);
			//REMOVER - END
			
			/*
			 * 2 - Criar Processo
			 */
			if (jsonRows != null){
				for (JSONObject jsonObject : jsonRows) {
					GenericTaskClient gtc = new GenericTaskClient();
					String paramAfterEncoding;
					
					paramAfterEncoding = URLEncoder.encode(jsonObject.toString());		
					JSONObject result = gtc.ajaxPostCall(gtc.START_PROCESS_TESTE +  "&params=" + paramAfterEncoding );
					
					if (result != null ){
						if ( ! "200".equalsIgnoreCase(result.getString("status")) ){
							System.out.println("[ERRO] Linha: " + jsonObject);				
						} else {
							System.out.println("[SUCESSO] linha: " + jsonObject);
						}
					} else{
						System.out.println("[ERRO] Linha: " + jsonObject);
					}
				}				
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (IllegalStateException e) {
			e.printStackTrace();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		
		return "PROCESS TESTE";
	}
	
	public static void main(String[] args) {
		ProcessFile c = new ProcessFile();
		c.process("");
	}

}