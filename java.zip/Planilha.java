package com.scalait.to;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

public interface Planilha {
	
	public List<JSONObject> readXLSExcel(FileInputStream fis) throws IOException, JSONException;
}
