package com.scalait.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.resource.spi.security.PasswordCredential;
import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreProtocolPNames;
import org.json.JSONException;
import org.json.JSONObject;

import com.ibm.websphere.security.NotImplementedException;
import com.ibm.ws.security.auth.callback.WSMappingCallbackHandlerFactoryImpl;

public class GenericTaskClient {	
	
	protected final String BIND_AUTH_ALIAS = "processServerUser";
	protected final String TASK_QUERY_PROPONENTE = "/rest/bpm/wle/v1/tasks/query/TasksByProponenteId?searchFilter=";
	protected final String TASK_DETAIL = "/rest/bpm/wle/v1/task";	
	protected final String TASK_SAVE = "/rest/bpm/wle/v1/service";
	protected final String TASK_FINISH = "/rest/bpm/wle/v1/task";
	
	
	//https://bpm855pc.local:9443/rest/bpm/wle/v1/process?action=start&bpdId=25.6929e568-53ce-484f-aceb-04010485eacc&processAppId=2066.7fbc8e2c-93c3-490c-99a2-a8b552041072&params=%7B%22number%22:10%7D&parts=none
	protected final String START_PROCESS_TESTE = "/rest/bpm/wle/v1/process?action=start&bpdId=25.6929e568-53ce-484f-aceb-04010485eacc&processAppId=2066.7fbc8e2c-93c3-490c-99a2-a8b552041072";

	private String  bindUser;
	private String  bindPassword;
	private URL processServerURL;
	
	protected GenericTaskClient() {
		this.getUserAndSenha();
        processServerURL = this.getProcessServerURL();
        
//        this.bindUser = "admin";
//        this.bindPassword = "admin";
//        try {
//			this.processServerURL = new URL("http://bpm855pc.local:9080");
//		} catch (MalformedURLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}	
	
	protected JSONObject ajaxGetCall(String path) throws IOException, URISyntaxException, IllegalStateException, JSONException{
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpGet getRequest;
		JSONObject jsonResponse = null;
		
		try {
			getRequest = new HttpGet(this.processServerURL.toURI() + path);
			getRequest.setHeader("Accept", "application/json");
			getRequest.setHeader("Cache-Control", "no-cache");
			getRequest.setHeader("Pragma", "no-cache");
								
			httpClient.getParams().setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);			
			httpClient.getParams().setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET, "UTF-8");
					
			
			httpClient.getCredentialsProvider().setCredentials( new AuthScope(this.processServerURL.getHost(), this.processServerURL.getPort()), new UsernamePasswordCredentials(bindUser, bindPassword));
			
			HttpResponse resp = httpClient.execute(getRequest);			
			jsonResponse = GenericTaskClient.convertInputStreamToJSONObject(resp.getEntity().getContent());
			
		} finally {			
			httpClient.getConnectionManager().shutdown();
		}		
		return jsonResponse;
	}
	
	/**
	 * Metodo responsavel por armazenar as informacoes do form.
	 *  
	 * @param path
	 * @return
	 * @throws URISyntaxException 
	 * @throws ClientProtocolException
	 * @throws IOException
	 * @throws JSONException 
	 * @throws IllegalStateException 
	 */
	
	protected JSONObject ajaxPutCall(String path) throws URISyntaxException, ClientProtocolException, IOException, IllegalStateException, JSONException{
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPut putRequest;
		JSONObject jsonResponse = null;
		
		try {
			putRequest = new HttpPut(this.processServerURL.toURI() + path);
			putRequest.setHeader("Accept", "application/json");
			putRequest.setHeader("Cache-Control", "no-cache");
			putRequest.setHeader("Pragma", "no-cache");
								
			httpClient.getParams().setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);			
			httpClient.getParams().setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET, "UTF-8");
			
			httpClient.getCredentialsProvider().setCredentials( new AuthScope(this.processServerURL.getHost(), this.processServerURL.getPort()), new UsernamePasswordCredentials(bindUser, bindPassword));
			
			System.out.println("putRequest.getURI().toString(): " + putRequest.getURI().toString() );
			
			HttpResponse resp = httpClient.execute(putRequest);
			jsonResponse = GenericTaskClient.convertInputStreamToJSONObject(resp.getEntity().getContent());			
			
		} finally {			
			httpClient.getConnectionManager().shutdown();
		}	
		
		return jsonResponse;
	}
	
	protected JSONObject ajaxPostCall(String path) throws URISyntaxException, ClientProtocolException, IOException, IllegalStateException, JSONException{
		DefaultHttpClient httpClient = new DefaultHttpClient();
		HttpPost postRequest;
		JSONObject jsonResponse = null;
		
		try {
			postRequest = new HttpPost(this.processServerURL.toURI() + path);
			
			postRequest.setHeader("Accept", "application/json");
			postRequest.setHeader("Cache-Control", "no-cache");
			postRequest.setHeader("Pragma", "no-cache");
								
			httpClient.getParams().setParameter(CoreProtocolPNames.PROTOCOL_VERSION, HttpVersion.HTTP_1_1);			
			httpClient.getParams().setParameter(CoreProtocolPNames.HTTP_CONTENT_CHARSET, "UTF-8");
			
			httpClient.getCredentialsProvider().setCredentials( new AuthScope(this.processServerURL.getHost(), this.processServerURL.getPort()), new UsernamePasswordCredentials(bindUser, bindPassword));
			
			System.out.println("postRequest.getURI().toString(): " + postRequest.getURI().toString() );
			
			HttpResponse resp = httpClient.execute(postRequest);
			jsonResponse = GenericTaskClient.convertInputStreamToJSONObject(resp.getEntity().getContent());			
			
		} finally {			
			httpClient.getConnectionManager().shutdown();
		}	
		
		return jsonResponse;
	}
	
	protected void getUserAndSenha()
	{  		
        // Obtem usuario e senha a partir de um J2C Authentication Alias
        HashMap map = new HashMap();
        map.put("com.ibm.mapping.authDataAlias", BIND_AUTH_ALIAS); //BPC_Auth_Alias
        
        try{
	        CallbackHandler callbackHandler = WSMappingCallbackHandlerFactoryImpl.getInstance().getCallbackHandler(map, null);
	        LoginContext lc = new LoginContext("DefaultPrincipalMapping", callbackHandler);
	        lc.login();
	        Subject sub = lc.getSubject();
	
	        bindUser = "";
	        bindPassword = "";
	
	        Object[] list_public = sub.getPrivateCredentials().toArray();
	        for (int i = 0; i < list_public.length; i++) {
	            if (list_public[i] instanceof PasswordCredential) {
	            	bindUser = ((PasswordCredential) list_public[i]).getUserName();
	            	bindPassword = new String(((PasswordCredential) list_public[i]).getPassword());
	            }
	        }  
	        
	        // Cria um contexto de Login para ser propagado para o container do
	        // WPS
	        //lc = new LoginContext("WSLogin", new WSCallbackHandlerImpl(bindUser, bindPassword));
	        //lc.login();
	        //sub = lc.getSubject();
	        //com.ibm.websphere.security.auth.WSSubject.setRunAsSubject(sub);
	       
        
        }catch(LoginException e){        	
        	e.printStackTrace();
        } catch (NotImplementedException e) {
			e.printStackTrace();
		}    
	}
	
	protected URL getProcessServerURL(){
		
		URL url = null;
		InitialContext initCtx;
		
		try {
			initCtx = new InitialContext();
			url = (java.net.URL) initCtx.lookup("url/processServerHost");			
		} catch (NamingException e) {
			e.printStackTrace();
		}				
		return url;
	}
	
	protected boolean isInitOk(HttpServletRequest request, HttpServletResponse response) throws IOException{		
		if (bindUser == null || bindPassword == null || bindUser == "" || bindPassword == "" || this.processServerURL == null){			
		    return false;
        }		
		return true;
	}
	
	private static JSONObject convertInputStreamToJSONObject(InputStream inputStream) throws JSONException, IOException {
	    BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream, "UTF-8"));
	    String line = "";
	    String result = "";
	    while((line = bufferedReader.readLine()) != null)
	        result += line;

	    inputStream.close();
	    return new JSONObject(result); 
	}
	
	public static void main(String[] args) {
		GenericTaskClient g = new GenericTaskClient();
		String paramAfterEncoding;
		try {
			paramAfterEncoding = URLEncoder.encode("{\"number\":101}", "UTF-8");		
			g.ajaxPostCall(g.START_PROCESS_TESTE +  "&params=" + paramAfterEncoding );
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}