package com.scalait.to;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.json.JSONException;
import org.json.JSONObject;

public class PlanilhaTeste implements Planilha {

	@Override
	public List<JSONObject> readXLSExcel(FileInputStream fis) throws IOException, JSONException {
		List<JSONObject> results = new ArrayList<JSONObject>();
		
		System.out.println("[PlanilhaTeste] readXLSExcel");
		// Finds the workbook instance for XLSX file
		HSSFWorkbook myWorkBook = new HSSFWorkbook (fis);		

        // Return first sheet from the XLSX workbook
		HSSFSheet mySheet = myWorkBook.getSheetAt(0);

        // Get iterator to all the rows in current sheet
        Iterator<Row> rowIterator = mySheet.iterator();
       
        // Traversing over each row of XLSX file
        while (rowIterator.hasNext()) {
        	JSONObject jsonRow = new JSONObject();
            Row row = rowIterator.next();

            // For each row, iterate through each columns
            Iterator<Cell> cellIterator = row.cellIterator();            
            
	    	while (cellIterator.hasNext()) {
	    		Cell cell = cellIterator.next();

               switch (cell.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                	jsonRow.put("string", cell.getStringCellValue());
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                	jsonRow.put("number", cell.getNumericCellValue());
                    break;
                case Cell.CELL_TYPE_BOOLEAN:
                    break;
                default :
             
                }
            }
	    	
	    	results.add(jsonRow);
        }
		
		return results;
	}

}
